/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { 
  Shield, 
  Users, 
  Search, 
  FileText, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Clock, 
  ExternalLink, 
  Plus, 
  Ban,
  ChevronLeft,
  BarChart3,
  Gavel,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Mock Data ---

const MOCK_REPORTS = [
  { id: 'R101', gameId: 'G-9928', suspect: 'GrandMaster_X', reporter: 'Player123', reason: 'שימוש במנוע עזר', status: 'פתוח', date: '2026-04-05' },
  { id: 'R102', gameId: 'G-8812', suspect: 'SpeedyKnight', reporter: 'ChessLover', reason: 'הטרדה בצ׳אט', status: 'בטיפול', date: '2026-04-06' },
  { id: 'R103', gameId: 'G-7734', suspect: 'NoobStomper', reporter: 'RookMaster', reason: 'משיכת זמן מכוונת', status: 'סגור', date: '2026-04-04' },
  { id: 'R104', gameId: 'G-6655', suspect: 'QueenSlayer', reporter: 'PawnStar', reason: 'חשד למכירת משחק', status: 'פתוח', date: '2026-04-06' },
];

const MOCK_PLAYER_HISTORY = {
  'GrandMaster_X': {
    username: 'GrandMaster_X',
    rating: 2450,
    joinDate: '2024-01-12',
    status: 'פעיל',
    reportsAgainst: [
      { id: 'R090', reason: 'חשד למנוע', date: '2025-12-20', result: 'לא נמצאו ראיות' },
      { id: 'R101', reason: 'שימוש במנוע עזר', date: '2026-04-05', result: 'בחקירה' },
    ],
    bans: [],
    investigations: ['INV-202']
  },
  'SpeedyKnight': {
    username: 'SpeedyKnight',
    rating: 1800,
    joinDate: '2025-05-20',
    status: 'מושעה זמנית',
    reportsAgainst: [
      { id: 'R085', reason: 'הטרדה', date: '2026-02-10', result: 'אזהרה' },
      { id: 'R102', reason: 'הטרדה בצ׳אט', date: '2026-04-06', result: 'מושעה' },
    ],
    bans: [{ type: 'צ׳אט', duration: '7 ימים', date: '2026-04-06' }],
    investigations: []
  }
};

const MOCK_INVESTIGATION = {
  id: 'INV-202',
  target: 'GrandMaster_X',
  startedAt: '2026-04-05',
  status: 'פעיל',
  description: 'ניתוח רמת דיוק חריגה במשחק G-9928. השחקן הציג דיוק של 99.8% לאורך 45 מהלכים.',
  evidence: [
    { id: 1, link: 'https://chess.com/analysis/G-9928', description: 'דוח ניתוח מנוע - דיוק חריג' },
    { id: 2, link: 'https://chess.com/game/G-9928', description: 'קישור למשחק המקורי' }
  ]
};

// --- Components ---

const LoginModal = ({ onLogin }: { onLogin: (role: 'player' | 'moderator') => void }) => {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8 text-center border border-slate-200"
      >
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-red-50 rounded-full">
            <Shield className="w-12 h-12 text-red-600" />
          </div>
        </div>
        <h1 className="text-2xl font-bold text-slate-900 mb-2">ברוכים הבאים למערכת FairPlay</h1>
        <p className="text-slate-500 mb-8">אנא בחר את סוג החיבור שלך למערכת</p>
        
        <div className="space-y-4">
          <button 
            onClick={() => onLogin('player')}
            className="w-full py-4 bg-white border-2 border-slate-200 rounded-xl font-bold text-slate-700 hover:border-red-500 hover:text-red-600 transition-all flex items-center justify-center gap-3 group"
          >
            <Users className="w-5 h-5 group-hover:scale-110 transition-transform" />
            היכנס כשחקן
          </button>
          <button 
            onClick={() => onLogin('moderator')}
            className="w-full py-4 bg-slate-900 rounded-xl font-bold text-white hover:bg-slate-800 transition-all flex items-center justify-center gap-3 group shadow-lg"
          >
            <Shield className="w-5 h-5 group-hover:scale-110 transition-transform" />
            היכנס כאיש צוות
          </button>
        </div>
      </motion.div>
    </div>
  );
};

const Navbar = ({ activeTab, setActiveTab, userRole, onLogout }: { activeTab: string, setActiveTab: (tab: string) => void, userRole: 'player' | 'moderator', onLogout: () => void }) => {
  const moderatorTabs = [
    { id: 'dashboard', label: 'דשבורד מנהלים', icon: BarChart3 },
    { id: 'profile', label: 'תיק שחקן', icon: Search },
    { id: 'investigation', label: 'חדר חקירות', icon: Gavel },
  ];

  if (userRole === 'player') {
    return (
      <header className="bg-slate-900 text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Shield className="w-8 h-8 text-red-500" />
              <span className="font-bold text-xl tracking-tight">FairPlay Chess</span>
            </div>
            <button 
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 rounded-md bg-slate-800 hover:bg-slate-700 transition-colors text-sm font-bold"
            >
              <LogOut className="w-4 h-4" />
              התנתק
            </button>
          </div>
        </div>
      </header>
    );
  }

  return (
    <nav className="bg-slate-900 text-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Shield className="w-8 h-8 text-red-500" />
            <span className="font-bold text-xl tracking-tight">FairPlay Chess</span>
          </div>
          <div className="flex gap-1 items-center">
            {moderatorTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-md transition-all duration-200 ${
                  activeTab === tab.id 
                    ? 'bg-red-600 text-white shadow-md' 
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
            <div className="w-px h-6 bg-slate-700 mx-2" />
            <button 
              onClick={onLogout}
              className="flex items-center gap-2 px-4 py-2 rounded-md hover:bg-slate-800 transition-colors text-slate-300 hover:text-white text-sm font-bold"
            >
              <LogOut className="w-4 h-4" />
              התנתק
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

const PlayerPortal = () => {
  const [formType, setFormType] = useState<'report' | 'appeal'>('report');

  return (
    <div className="max-w-2xl mx-auto py-8 px-4">
      <div className="bg-white rounded-xl shadow-xl overflow-hidden border border-slate-200">
        <div className="flex border-b border-slate-200">
          <button 
            onClick={() => setFormType('report')}
            className={`flex-1 py-4 font-bold text-lg transition-colors ${formType === 'report' ? 'bg-red-50 text-red-600 border-b-2 border-red-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            דיווח על שחקן
          </button>
          <button 
            onClick={() => setFormType('appeal')}
            className={`flex-1 py-4 font-bold text-lg transition-colors ${formType === 'appeal' ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-600' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            הגשת ערעור
          </button>
        </div>

        <div className="p-8">
          {formType === 'report' ? (
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">מזהה משחק (Game ID)</label>
                  <input type="text" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none" placeholder="לדוגמה: G-1234" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">שם משתמש של החשוד</label>
                  <input type="text" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none" placeholder="שם המשתמש..." />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">סיבת הדיווח</label>
                <select className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none bg-white">
                  <option>בחר סיבה...</option>
                  <option>שימוש במנוע עזר (Cheating)</option>
                  <option>הטרדה בצ׳אט</option>
                  <option>משיכת זמן מכוונת</option>
                  <option>מכירת משחק / שיתוף פעולה</option>
                  <option>אחר</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">תיאור חופשי</label>
                <textarea className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none h-32" placeholder="ספר לנו מה קרה..."></textarea>
              </div>
              <button className="w-full bg-red-600 text-white font-bold py-3 rounded-lg hover:bg-red-700 transition-colors shadow-lg">
                שלח דיווח
              </button>
            </form>
          ) : (
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">מזהה השעיה / דיווח</label>
                <input type="text" className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" placeholder="הכנס מזהה..." />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-2">נימוק לערעור</label>
                <textarea className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none h-48" placeholder="מדוע לדעתך ההחלטה שגויה?"></textarea>
              </div>
              <button className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition-colors shadow-lg">
                שלח ערעור
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

const ModeratorDashboard = () => {
  const [filter, setFilter] = useState('הכל');

  const stats = [
    { label: 'דיווחים פתוחים', value: 124, icon: AlertTriangle, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'השעיות פעילות', value: 45, icon: Ban, color: 'text-red-500', bg: 'bg-red-50' },
    { label: 'חקירות בטיפול', value: 12, icon: Clock, color: 'text-blue-500', bg: 'bg-blue-50' },
    { label: 'ערעורים ממתינים', value: 8, icon: FileText, color: 'text-purple-500', bg: 'bg-purple-50' },
  ];

  const filteredReports = useMemo(() => {
    if (filter === 'הכל') return MOCK_REPORTS;
    return MOCK_REPORTS.filter(r => r.status === filter);
  }, [filter]);

  return (
    <div className="max-w-7xl mx-auto py-8 px-4 space-y-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 flex items-center gap-4">
            <div className={`p-3 rounded-lg ${stat.bg}`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">{stat.label}</p>
              <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Table Section */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <h2 className="text-xl font-bold text-slate-900">דיווחים ממתינים לטיפול</h2>
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-500">סנן לפי:</span>
            <select 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-3 py-1 border border-slate-300 rounded-md text-sm outline-none focus:ring-2 focus:ring-red-500"
            >
              <option>הכל</option>
              <option>פתוח</option>
              <option>בטיפול</option>
              <option>סגור</option>
            </select>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-right">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 text-sm font-bold text-slate-600">מזהה</th>
                <th className="px-6 py-4 text-sm font-bold text-slate-600">חשוד</th>
                <th className="px-6 py-4 text-sm font-bold text-slate-600">סיבה</th>
                <th className="px-6 py-4 text-sm font-bold text-slate-600">תאריך</th>
                <th className="px-6 py-4 text-sm font-bold text-slate-600">סטטוס</th>
                <th className="px-6 py-4 text-sm font-bold text-slate-600">פעולות</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredReports.map((report) => (
                <tr key={report.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 text-sm font-medium text-slate-900">{report.id}</td>
                  <td className="px-6 py-4 text-sm text-slate-700">{report.suspect}</td>
                  <td className="px-6 py-4 text-sm text-slate-700">{report.reason}</td>
                  <td className="px-6 py-4 text-sm text-slate-500">{report.date}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                      report.status === 'פתוח' ? 'bg-red-100 text-red-700' :
                      report.status === 'בטיפול' ? 'bg-blue-100 text-blue-700' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {report.status}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-red-600 hover:text-red-800 font-bold text-sm">פתח חקירה</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

const PlayerProfile = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [foundPlayer, setFoundPlayer] = useState<any>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const player = MOCK_PLAYER_HISTORY[searchQuery as keyof typeof MOCK_PLAYER_HISTORY];
    setFoundPlayer(player || null);
  };

  return (
    <div className="max-w-5xl mx-auto py-8 px-4 space-y-8">
      {/* Search Bar */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <form onSubmit={handleSearch} className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-10 pl-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-red-500 outline-none"
              placeholder="חפש שם משתמש (נסה: GrandMaster_X או SpeedyKnight)"
            />
          </div>
          <button type="submit" className="bg-slate-900 text-white px-8 py-3 rounded-lg font-bold hover:bg-slate-800 transition-colors">
            חפש
          </button>
        </form>
      </div>

      {foundPlayer ? (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 lg:grid-cols-3 gap-8"
        >
          {/* Main Info Card */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200 text-center">
              <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-slate-50">
                <Users className="w-12 h-12 text-slate-400" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900">{foundPlayer.username}</h2>
              <p className="text-slate-500 mb-4">דירוג: {foundPlayer.rating}</p>
              <div className={`inline-block px-4 py-1 rounded-full text-sm font-bold ${
                foundPlayer.status === 'פעיל' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {foundPlayer.status}
              </div>
              <div className="mt-6 pt-6 border-t border-slate-100 text-right space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">תאריך הצטרפות:</span>
                  <span className="font-medium">{foundPlayer.joinDate}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">חקירות פעילות:</span>
                  <span className="font-medium">{foundPlayer.investigations.length}</span>
                </div>
              </div>
            </div>

            {foundPlayer.bans.length > 0 && (
              <div className="bg-red-50 p-6 rounded-xl border border-red-100">
                <h3 className="text-red-800 font-bold mb-4 flex items-center gap-2">
                  <Ban className="w-5 h-5" />
                  היסטוריית השעיות
                </h3>
                {foundPlayer.bans.map((ban: any, i: number) => (
                  <div key={i} className="text-sm text-red-700 bg-white p-3 rounded border border-red-200 mb-2">
                    <p><strong>סוג:</strong> {ban.type}</p>
                    <p><strong>משך:</strong> {ban.duration}</p>
                    <p><strong>תאריך:</strong> {ban.date}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* History Tables */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="p-6 border-b border-slate-200">
                <h3 className="font-bold text-slate-900">דיווחים קודמים נגד השחקן</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-right">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase">מזהה</th>
                      <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase">סיבה</th>
                      <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase">תאריך</th>
                      <th className="px-6 py-3 text-xs font-bold text-slate-500 uppercase">תוצאה</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {foundPlayer.reportsAgainst.map((report: any) => (
                      <tr key={report.id}>
                        <td className="px-6 py-4 text-sm text-slate-900">{report.id}</td>
                        <td className="px-6 py-4 text-sm text-slate-700">{report.reason}</td>
                        <td className="px-6 py-4 text-sm text-slate-500">{report.date}</td>
                        <td className="px-6 py-4">
                          <span className={`text-xs font-bold ${
                            report.result === 'בחקירה' ? 'text-blue-600' : 
                            report.result === 'מושעה' ? 'text-red-600' : 'text-slate-500'
                          }`}>
                            {report.result}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </motion.div>
      ) : searchQuery && (
        <div className="text-center py-12 bg-white rounded-xl border border-slate-200 shadow-sm">
          <XCircle className="w-12 h-12 text-slate-300 mx-auto mb-4" />
          <p className="text-slate-500 font-medium">לא נמצא שחקן בשם "{searchQuery}"</p>
        </div>
      )}
    </div>
  );
};

const InvestigationRoom = () => {
  const [investigation, setInvestigation] = useState(MOCK_INVESTIGATION);
  const [newEvidence, setNewEvidence] = useState({ link: '', description: '' });

  const addEvidence = () => {
    if (!newEvidence.link || !newEvidence.description) return;
    setInvestigation({
      ...investigation,
      evidence: [...investigation.evidence, { id: Date.now(), ...newEvidence }]
    });
    setNewEvidence({ link: '', description: '' });
  };

  const handleBan = () => {
    setInvestigation({ ...investigation, status: 'הושלם - הושעה' });
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Details & Actions */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-slate-900">פרטי חקירה</h2>
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                investigation.status === 'פעיל' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
              }`}>
                {investigation.status}
              </span>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase">מזהה חקירה</p>
                <p className="font-mono text-slate-900">{investigation.id}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase">שחקן תחת חקירה</p>
                <p className="font-bold text-red-600 text-lg">{investigation.target}</p>
              </div>
              <div>
                <p className="text-xs text-slate-500 font-bold uppercase">תאריך התחלה</p>
                <p className="text-slate-700">{investigation.startedAt}</p>
              </div>
              <div className="pt-4 border-t border-slate-100">
                <p className="text-xs text-slate-500 font-bold uppercase mb-2">תיאור המקרה</p>
                <p className="text-sm text-slate-700 leading-relaxed">{investigation.description}</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 p-6 rounded-xl shadow-lg text-white">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-red-500" />
              פעולות משמעתיות
            </h3>
            <div className="space-y-3">
              <button 
                onClick={handleBan}
                disabled={investigation.status.includes('הושעה')}
                className="w-full bg-red-600 hover:bg-red-700 disabled:bg-slate-700 disabled:cursor-not-allowed text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Ban className="w-4 h-4" />
                השעה שחקן לצמיתות
              </button>
              <button className="w-full bg-slate-800 hover:bg-slate-700 text-white font-bold py-3 rounded-lg transition-colors">
                שלח אזהרה רשמית
              </button>
              <button className="w-full border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold py-3 rounded-lg transition-colors">
                סגור תיק ללא פעולה
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Evidence List */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
            <h3 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
              <FileText className="w-5 h-5 text-blue-500" />
              ראיות וממצאים
            </h3>
            
            <div className="space-y-4 mb-8">
              {investigation.evidence.map((ev) => (
                <div key={ev.id} className="flex items-start justify-between p-4 bg-slate-50 rounded-lg border border-slate-100 group">
                  <div>
                    <p className="font-bold text-slate-900 mb-1">{ev.description}</p>
                    <a href={ev.link} target="_blank" rel="noreferrer" className="text-blue-600 text-sm flex items-center gap-1 hover:underline">
                      {ev.link}
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                  <button className="text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity">
                    <XCircle className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-slate-100">
              <h4 className="font-bold text-slate-800 mb-4">הוספת ראיה חדשה</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <input 
                  type="text" 
                  placeholder="קישור (URL)" 
                  value={newEvidence.link}
                  onChange={(e) => setNewEvidence({ ...newEvidence, link: e.target.value })}
                  className="px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                />
                <input 
                  type="text" 
                  placeholder="תיאור קצר" 
                  value={newEvidence.description}
                  onChange={(e) => setNewEvidence({ ...newEvidence, description: e.target.value })}
                  className="px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <button 
                onClick={addEvidence}
                className="bg-blue-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                הוסף לרשימה
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [userRole, setUserRole] = useState<'player' | 'moderator' | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  const handleLogin = (role: 'player' | 'moderator') => {
    setUserRole(role);
    if (role === 'player') {
      setActiveTab('portal');
    } else {
      setActiveTab('dashboard');
    }
  };

  const handleLogout = () => {
    setUserRole(null);
  };

  const renderContent = () => {
    if (userRole === 'player') return <PlayerPortal />;
    
    switch (activeTab) {
      case 'dashboard': return <ModeratorDashboard />;
      case 'profile': return <PlayerProfile />;
      case 'investigation': return <InvestigationRoom />;
      default: return <ModeratorDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans" dir="rtl">
      <AnimatePresence>
        {userRole === null && (
          <LoginModal onLogin={handleLogin} />
        )}
      </AnimatePresence>

      {userRole !== null && (
        <>
          <Navbar 
            activeTab={activeTab} 
            setActiveTab={setActiveTab} 
            userRole={userRole} 
            onLogout={handleLogout} 
          />
          
          <main className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
              >
                {renderContent()}
              </motion.div>
            </AnimatePresence>
          </main>
        </>
      )}

      <footer className="py-8 text-center text-slate-400 text-sm border-t border-slate-200 mt-12">
        <p>© 2026 FairPlay Chess - מחלקת הגינות ומשחק הוגן</p>
      </footer>
    </div>
  );
}
